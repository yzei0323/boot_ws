package com.example.ExceptionEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionExApplicationTests {

	@Test
	void contextLoads() {
	}

}
