package com.example.thyeleafLayout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThyeleafLayoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThyeleafLayoutApplication.class, args);
	}

}
