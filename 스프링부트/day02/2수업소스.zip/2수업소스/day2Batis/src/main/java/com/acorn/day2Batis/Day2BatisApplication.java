package com.acorn.day2Batis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2BatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day2BatisApplication.class, args);
	}


}
