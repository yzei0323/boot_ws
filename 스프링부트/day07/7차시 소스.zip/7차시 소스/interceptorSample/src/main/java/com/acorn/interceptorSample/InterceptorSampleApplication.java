package com.acorn.interceptorSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InterceptorSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(InterceptorSampleApplication.class, args);
	}

}
