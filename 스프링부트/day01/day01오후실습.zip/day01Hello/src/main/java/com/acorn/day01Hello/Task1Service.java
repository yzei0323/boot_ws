package com.acorn.day01Hello;

import org.springframework.stereotype.Service;

@Service
public class Task1Service {
    public int add(int su1, int su2) {
        return su1+su2;
    }
}
