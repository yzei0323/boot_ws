package com.example.booklib;

import lombok.Data;

@Data
public class SignUpCondition {
    String user_id;
    String user_name;
    String user_pw;
}
