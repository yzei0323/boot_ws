package com.example.booklib;

public class UserDTO {
    String user_id;
    String user_name;
    String user_pw;
}
