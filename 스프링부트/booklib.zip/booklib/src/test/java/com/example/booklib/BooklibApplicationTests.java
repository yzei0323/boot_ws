package com.example.booklib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooklibApplicationTests {

	@Test
	void contextLoads() {
	}

}
