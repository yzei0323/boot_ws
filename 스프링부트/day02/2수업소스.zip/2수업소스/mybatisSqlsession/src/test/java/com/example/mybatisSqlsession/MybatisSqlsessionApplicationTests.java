package com.example.mybatisSqlsession;



import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MybatisSqlsessionApplicationTests {



}
