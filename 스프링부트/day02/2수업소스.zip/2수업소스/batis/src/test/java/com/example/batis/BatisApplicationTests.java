package com.example.batis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
