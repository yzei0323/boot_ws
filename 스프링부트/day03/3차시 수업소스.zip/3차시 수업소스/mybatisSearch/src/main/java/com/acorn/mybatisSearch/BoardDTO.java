package com.acorn.mybatisSearch;


import lombok.Data;

@Data
public class BoardDTO {

    private int boardNo;
    private String title;
    private String writer;
    private String content;
}
