package com.acorn.day1;


import lombok.Data;

@Data
public class Food {
    String code;
    String name;
    int price;

}
