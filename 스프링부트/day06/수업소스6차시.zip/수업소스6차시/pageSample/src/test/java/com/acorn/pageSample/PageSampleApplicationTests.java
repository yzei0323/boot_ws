package com.acorn.pageSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PageSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
