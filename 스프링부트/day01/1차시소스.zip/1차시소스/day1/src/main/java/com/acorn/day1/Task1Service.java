package com.acorn.day1;


import org.springframework.stereotype.Service;

@Service
public class Task1Service {


    public int calc( int su1, int su2){
        return su1+su2;
    }
}
