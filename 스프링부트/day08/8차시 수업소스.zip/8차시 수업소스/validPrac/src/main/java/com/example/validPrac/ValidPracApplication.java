package com.example.validPrac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidPracApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidPracApplication.class, args);
	}

}
