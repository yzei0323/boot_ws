package com.acorn.day01Hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day01HelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
