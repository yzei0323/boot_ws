package com.acorn.Prac;

import lombok.Data;

@Data
public class Book_lib {

    String lib_id;
    String lib_name;

}
