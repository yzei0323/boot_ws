package com.example.validPrac;


import lombok.Data;

@Data
public class Order {

    String name;
    Integer price;
    Integer qty;
}
