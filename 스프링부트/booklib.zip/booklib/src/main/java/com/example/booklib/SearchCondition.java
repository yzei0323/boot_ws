package com.example.booklib;

import lombok.Data;

@Data
public class SearchCondition {
    String condition;
    String keyword;
}
