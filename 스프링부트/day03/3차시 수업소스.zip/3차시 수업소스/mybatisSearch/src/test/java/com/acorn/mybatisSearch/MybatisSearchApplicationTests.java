package com.acorn.mybatisSearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
