package com.acorn.publicData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PublicDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(PublicDataApplication.class, args);
	}

}
