package com.acorn.publicData.test;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ItemDTO {
    String informGrade  ;
    String informCause ;
    String dataTime ;

}
