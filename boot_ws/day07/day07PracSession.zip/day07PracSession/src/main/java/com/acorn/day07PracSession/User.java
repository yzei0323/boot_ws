package com.acorn.day07PracSession;

import lombok.Data;

@Data
public class User {
    String id;
    String pw;
}
