package com.example.validPrac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidPracApplicationTests {

	@Test
	void contextLoads() {
	}

}
