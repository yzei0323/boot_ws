package com.example.uploadEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadExApplicationTests {

	@Test
	void contextLoads() {
	}

}
