package com.acorn.validTest;

import lombok.Data;

@Data
public class Order {

    String name;
    Integer price;
    Integer qty;


}
