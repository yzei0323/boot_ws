package com.acorn.mybatisSearch;

import lombok.Data;

@Data
public class SearchCondition {

	String condition ;
	String keyword;
	 
}
