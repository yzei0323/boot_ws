package com.example.booklib;

import lombok.Data;

@Data
public class BookLibDTO {
    String lib_id;
    String lib_name;
}
