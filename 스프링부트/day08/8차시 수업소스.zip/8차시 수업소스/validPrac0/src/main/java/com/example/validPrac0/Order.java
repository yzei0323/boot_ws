package com.example.validPrac0;


import lombok.Data;

@Data
public class Order {

    String name;
    Integer price;
    Integer qty;
}
