package com.acorn.validTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
