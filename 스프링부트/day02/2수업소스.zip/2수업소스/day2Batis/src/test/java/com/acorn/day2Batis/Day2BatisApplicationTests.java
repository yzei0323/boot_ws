package com.acorn.day2Batis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2BatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
