

function hi(){

  alert(" hi");
}