package com.example.validPrac0;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidPrac0Application {
	public static void main(String[] args) {
		SpringApplication.run(ValidPrac0Application.class, args);
	}

}
