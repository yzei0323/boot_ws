package com.acorn.validTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidTestApplication.class, args);
	}

}
