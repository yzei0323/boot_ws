package com.example.booklib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooklibApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooklibApplication.class, args);
	}

}
