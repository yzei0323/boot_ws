package com.acorn.day01Hello;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Book {

    String name;
    String author;
    int price;

}
