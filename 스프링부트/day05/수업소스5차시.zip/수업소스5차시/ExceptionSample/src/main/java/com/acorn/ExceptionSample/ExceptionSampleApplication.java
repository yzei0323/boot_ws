package com.acorn.ExceptionSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionSampleApplication.class, args);
	}

}
