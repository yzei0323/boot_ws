package com.example.mybatisSqlsession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisSqlsessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybatisSqlsessionApplication.class, args);
	}

}
