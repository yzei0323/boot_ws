package com.acorn.day1;


import lombok.Data;

@Data
public class Acorn {

    String id;
    String pw;
    String name;

}
